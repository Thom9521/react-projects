export const DRINK = "DRINK";
export const PAY = "PAY";
export const NO = "NO";
export const RUN = "RUN";
