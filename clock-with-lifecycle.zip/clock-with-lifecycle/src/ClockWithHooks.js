import React, { useState, useEffect } from "react";

function ClockWithHooks() {
  const [seconds, setSeconds] = useState(0);
  const [minutes, setMinutes] = useState(0);
  const [text, setText] = useState("Rdy?");

  // By using this Hook, you tell React that your component needs to do something after render
  // useEffect lets us express different kinds of side effects after a component renders
  useEffect(() => {
    setTimeout(() => {
      if (seconds === 59) {
        setSeconds(0);
        setMinutes(minutes + 1);
      } else {
        setText("Go!");
        setSeconds(seconds + 1);
      }
    }, 1000);
  });
  return (
    <div>
      <h6>(With hooks)</h6>
      <h1>{text}</h1>
      <h2>
        {("0" + minutes).slice(-2)}:{("0" + seconds).slice(-2)}
      </h2>
    </div>
  );
}

export default ClockWithHooks;
