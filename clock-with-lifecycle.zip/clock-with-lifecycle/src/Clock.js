import React from "react";

class Clock extends React.Component {
  constructor(props) {
    super(props);
    this.state = { seconds: 0, minutes: 0, text: "Rdy?" };
  }
  componentDidMount() {
    setTimeout(() => {
      this.setState({ seconds: this.state.seconds + 1, text: "Go!" });
    }, 1000);
  }
  componentDidUpdate() {
    setTimeout(() => {
      if (this.state.seconds === 59) {
        this.setState({ seconds: 0, minutes: this.state.minutes + 1 });
      } else {
        this.setState({ seconds: this.state.seconds + 1, text: "Go!" });
      }
    }, 1000);
  }

  render() {
    return (
      <div>
        <h6>(Without hooks)</h6>
        <h1>{this.state.text}</h1>
        <h2>
          {("0" + this.state.minutes).slice(-2)}:
          {("0" + this.state.seconds).slice(-2)}{" "}
        </h2>
      </div>
    );
  }
}
export default Clock;
