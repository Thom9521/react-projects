import React from "react";
import "./App.css";
import Clock from "./Clock";
import ClockWithHooks from "./ClockWithHooks";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Timer ⏰</h1>
        <div className="mt-5">
          <Clock />
        </div>
        <div className="mt-5">
          <ClockWithHooks />
        </div>
      </header>
    </div>
  );
}

export default App;
